from users.serializers import TgUserSerializer
from users.models import User
from rest_framework import generics

# Create your views here.

class ListUsersView(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = TgUserSerializer

class EditUserView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = TgUserSerializer
    lookup_field = "user_id"