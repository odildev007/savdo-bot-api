from django.db import models

# Create your models here.

class User(models.Model):
    user_id = models.BigIntegerField(unique=True)
    user_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=13)
    address = models.TextField()
    city = models.CharField(max_length=100)
    balance = models.BigIntegerField()
    limit = models.FloatField()
    status = models.CharField(max_length=25)
    