from rest_framework.serializers import ModelSerializer
from . import models

class TgUserSerializer(ModelSerializer):
    class Meta:
        model = models.User
        fields = ["user_id", "user_name", "phone_number", "balance", "status"]


