from .serializers import BrandSerializer
from .models import Brand
from rest_framework import generics

# Create your views here.

class ListBrandsView(generics.ListCreateAPIView):
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer

class EditBrandView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer
    lookup_field = "id"
