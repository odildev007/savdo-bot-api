from django.urls import path
from .views import ListBrandsView, EditBrandView

app_name = "users"
urlpatterns = [
    path("", ListBrandsView.as_view(), name="brands"),
    path("<int:id>", EditBrandView.as_view(), name="edit_brand")
]