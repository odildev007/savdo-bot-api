from rest_framework.serializers import ModelSerializer
from . import models

class BasketSerializer(ModelSerializer):
    class Meta:
        model = models.Basket
        fields = ["user_id", "basket_id", "date", "status"]


