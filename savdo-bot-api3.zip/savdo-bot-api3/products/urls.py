from django.urls import path
from .views import ProductsView_by_category, ProductsView, ProductView

urlpatterns = [
    path("category/<int:category_id>", ProductsView_by_category.as_view(), name="Products filtering by category id"),
    path("<int:product_id>", ProductView.as_view(), name="Product"),
    path("", ProductsView.as_view(), name="Products")
]