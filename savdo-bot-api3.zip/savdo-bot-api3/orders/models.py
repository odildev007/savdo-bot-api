from django.db import models

# Create your models here.
class Order(models.Model):
    order_id = models.AutoField(primary_key=True, unique=True, auto_created=True)
    product_id = models.BigIntegerField()
    category_id = models.BigIntegerField()
    basket_id = models.BigIntegerField()
    name = models.CharField(max_length=120)
    size = models.CharField(max_length=120)
    price = models.FloatField()
    count = models.IntegerField()

