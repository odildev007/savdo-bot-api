from rest_framework.serializers import ModelSerializer
from .models import Order

class OrderSerializer(ModelSerializer):
    class Meta:
        model = Order
        fields = ["order_id", "product_id", "category_id", "basket_id", "name", "size", "price", "count"]
