from django.db import models
from categories.models import Category


# Create your models here.
class Product(models.Model):
    product_id = models.AutoField(primary_key=True, auto_created=True, unique=True)
    category_id = models.ForeignKey(to=Category, on_delete=models.DO_NOTHING)
    name = models.CharField(max_length=80)
    size = models.CharField(max_length=80)
    price = models.FloatField()
    count = models.IntegerField()

