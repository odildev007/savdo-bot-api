from django.urls import path
from .views import ListUsersView, EditUserView

app_name = "users"
urlpatterns = [
    path("", ListUsersView.as_view(), name="users"),
    path("<int:user_id>", EditUserView.as_view(), name="edit_user")
]
from django.urls import path
from .views import ListUsersView, EditUserView

app_name = "users"
urlpatterns = [
    path("", ListUsersView.as_view(), name="users"),
    path("<int:user_id>", EditUserView.as_view(), name="edit_user")
]
