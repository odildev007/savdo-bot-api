from django.db import models

# Create your models here.

class TgUser(models.Model):
    user_id = models.BigIntegerField(unique=True)
    user_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=13)
    balance = models.BigIntegerField()
    status = models.CharField(max_length=25)
    