from django.urls import path
from .views import OrdersView, OrdersView_by_basket_id, OrdersView_by_category_id, EditOrderView, OrdersView_by_product_id

urlpatterns = [
    path("product_id/<int:product_id>", OrdersView_by_product_id.as_view(), name="Orders_filtering_by_product_id"),
    path("category_id/<int:category_id>", OrdersView_by_category_id.as_view(), name="Orders_filtering_by_category_id"),
    path("basket_id/<int:basket_id>", OrdersView_by_basket_id.as_view(), name="Orders_filtering_by_basket_id"),
    path("", OrdersView.as_view(), name="Orders"),
    path("<int:order_id>", EditOrderView.as_view(), name="edit_rders"),
]