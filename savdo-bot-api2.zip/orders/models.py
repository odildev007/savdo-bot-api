from django.db import models
from products.models import Product
from categories.models import Category
from baskets.models import Basket

# Create your models here.
class Order(models.Model):
    order_id = models.AutoField(primary_key=True, unique=True, auto_created=True)
    product_id = models.ForeignKey(to=Product, on_delete=models.DO_NOTHING)
    category_id = models.ForeignKey(to=Category, on_delete=models.DO_NOTHING, )
    basket_id = models.ForeignKey(to=Basket, on_delete=models.DO_NOTHING)
    name = models.CharField(max_length=120)
    size = models.CharField(max_length=120)
    price = models.FloatField()
    count = models.IntegerField()

