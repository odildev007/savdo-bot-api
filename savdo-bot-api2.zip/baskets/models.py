from django.db import models
from users.models import TgUser

# Create your models here.
class Basket(models.Model):
    user_id = models.ForeignKey(to=TgUser, on_delete=models.DO_NOTHING)
    basket_id = models.AutoField(auto_created=True, primary_key=True, unique=True)
    date = models.DateField(auto_now=True)
    status = models.CharField(max_length=30)
    