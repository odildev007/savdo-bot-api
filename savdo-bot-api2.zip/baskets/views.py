from django.shortcuts import render
from .models import Basket
from rest_framework import generics
from .serializers import BasketSerializer

# Create your views here.
class BasketsView(generics.ListCreateAPIView):
    queryset = Basket.objects.all()
    serializer_class = BasketSerializer

class BasketView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Basket.objects.all()
    serializer_class = BasketSerializer
    lookup_field = "basket_id"

class BasketsView_by_user_id(generics.RetrieveAPIView):
    queryset = Basket.objects.all()
    serializer_class = BasketSerializer
    lookup_field = "user_id"

