from django.urls import path
from .views import BasketsView, BasketView, BasketsView_by_user_id


urlpatterns = [
    path("user/<int:user_id>", BasketsView_by_user_id.as_view(), name="basket_filtering_by_user_id"),
    path("<int:basket_id>", BasketView.as_view(), name="basket"),
    path("", BasketsView.as_view(), name="baskets")
]