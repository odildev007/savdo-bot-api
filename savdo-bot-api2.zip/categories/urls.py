from django.urls import path
from .views import AddCategoryView, EditCategoryView

urlpatterns = [
    path("", AddCategoryView.as_view(), name="categories"),
    path("<int:id>", EditCategoryView.as_view(), name="edit_category")
]  